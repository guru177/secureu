# CollegeComplaint — Java + MySQL

Runnable educational starter project aligned with the supplied CollegeComplaint database screenshot. Includes student/admin login, complaint submission, tracking, student complaint list, and admin status/remarks updates.

## Requirements
- JDK 17+
- MySQL Server and MySQL Workbench
- VS Code with the Extension Pack for Java
- Maven

## Setup
1. Open MySQL Workbench and connect to your local server.
2. Open `sql/CollegeComplaint.sql` and execute the full script.
3. In `src/main/java/collegecomplaint/App.java`, update `DB_USER` and `DB_PASSWORD`. Replace `YOUR_MYSQL_PASSWORD` with your local MySQL password.
4. Open this project folder in VS Code and wait for Maven to download MySQL Connector/J.
5. Run `App.java` using the **Run** link above `main`.

Alternatively, from a terminal with Maven installed:
```bash
mvn clean compile
```
Then use VS Code's Java Run command, or run the compiled application with the dependency classpath configured.

## Demo logins
- Student: `abhinav@example.com` / `student@123`
- Student: `sneha@example.com` / `student@123`
- Admin/Warden: `warden@example.com` / `admin@123`
- HOD: `hod@example.com` / `admin@123`

## Important
This is an educational demo. It compares plain-text passwords to match the simple reference schema; replace this with salted password hashing and stronger access controls before any real deployment. Evidence is stored as a filename only, not uploaded. No SMS/email alerts or anonymous-reporting guarantee are implemented. Never use real sensitive complaints or credentials in a demo database.
