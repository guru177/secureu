CREATE DATABASE IF NOT EXISTS CollegeComplaint;
USE CollegeComplaint;
CREATE TABLE IF NOT EXISTS students (
 student_id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100) NOT NULL,
 department VARCHAR(100), email VARCHAR(100) UNIQUE, password VARCHAR(255) NOT NULL, phone VARCHAR(15));
CREATE TABLE IF NOT EXISTS admin (
 admin_id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100) NOT NULL,
 role ENUM('Warden','HOD') NOT NULL, email VARCHAR(100) UNIQUE, password VARCHAR(255) NOT NULL);
CREATE TABLE IF NOT EXISTS complaints (
 complaint_id INT PRIMARY KEY AUTO_INCREMENT, student_id INT NULL,
 category VARCHAR(100) NOT NULL, description TEXT NOT NULL, evidence VARCHAR(255),
 status VARCHAR(30) NOT NULL DEFAULT 'Pending', date_filed DATE NOT NULL, remarks TEXT,
 CONSTRAINT fk_complaint_student FOREIGN KEY(student_id) REFERENCES students(student_id)
 ON DELETE SET NULL ON UPDATE CASCADE);
INSERT IGNORE INTO students(student_id,name,department,email,password,phone)
VALUES(1,'Abhinav U','CSE','abhinav@example.com','student@123','9876543210');
INSERT IGNORE INTO students(student_id,name,department,email,password,phone)
VALUES(2,'Sneha S','ECE','sneha@example.com','student@123','8765432109');
INSERT IGNORE INTO admin(admin_id,name,role,email,password)
VALUES(1,'Priya Nair','Warden','warden@example.com','admin@123');
INSERT IGNORE INTO admin(admin_id,name,role,email,password)
VALUES(2,'Suresh Babu','HOD','hod@example.com','admin@123');
