package collegecomplaint;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;

public class App {
    // CHANGE THESE TO MATCH YOUR LOCAL MYSQL LOGIN.
    static final String URL = "jdbc:mysql://localhost:3306/CollegeComplaint?serverTimezone=UTC";
    static final String DB_USER = "root";
    static final String DB_PASSWORD = "YOUR_MYSQL_PASSWORD";

    static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, DB_USER, DB_PASSWORD);
    }
    static JButton btn(String s) {
        JButton b = new JButton(s); b.setFocusPainted(false); return b;
    }
    static void error(Component c, Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(c, "Database/application error:\\n" + e.getMessage()
          + "\\nCheck MySQL is running and DB credentials in App.java.", "CollegeComplaint", JOptionPane.ERROR_MESSAGE);
    }
    static DefaultTableModel model(ResultSet rs) throws SQLException {
        ResultSetMetaData md=rs.getMetaData(); int n=md.getColumnCount();
        String[] cols=new String[n]; for(int i=1;i<=n;i++) cols[i-1]=md.getColumnLabel(i);
        DefaultTableModel m=new DefaultTableModel(cols,0) {
            public boolean isCellEditable(int r,int c){return false;}
        };
        while(rs.next()){Object[] row=new Object[n];for(int i=1;i<=n;i++)row[i-1]=rs.getObject(i);m.addRow(row);}
        return m;
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch(Exception ignored){}
            new Login().setVisible(true);
        });
    }

    static class Login extends JFrame {
        JTextField email=new JTextField(22); JPasswordField password=new JPasswordField(22);
        JComboBox<String> role=new JComboBox<>(new String[]{"Student","Administrator / Warden"});
        Login() {
            setTitle("CollegeComplaint - Login"); setDefaultCloseOperation(EXIT_ON_CLOSE); setSize(500,370); setLocationRelativeTo(null);
            JPanel p=new JPanel(new GridLayout(0,2,10,12)); p.setBorder(new EmptyBorder(25,30,20,30));
            p.add(new JLabel("Login as"));p.add(role);p.add(new JLabel("Email"));p.add(email);p.add(new JLabel("Password"));p.add(password);
            JButton login=btn("Login");p.add(new JLabel(""));p.add(login);
            p.add(new JLabel("Demo student:"));p.add(new JLabel("abhinav@example.com / student@123"));
            p.add(new JLabel("Demo admin:"));p.add(new JLabel("warden@example.com / admin@123"));
            add(p); getRootPane().setDefaultButton(login); login.addActionListener(e->doLogin());
        }
        void doLogin(){
            boolean admin=role.getSelectedIndex()==1;
            String sql=admin?"SELECT admin_id,name,role FROM admin WHERE email=? AND password=?":
                "SELECT student_id,name,department FROM students WHERE email=? AND password=?";
            try(Connection c=connect();PreparedStatement s=c.prepareStatement(sql)){
                s.setString(1,email.getText().trim());s.setString(2,new String(password.getPassword()));
                try(ResultSet r=s.executeQuery()){
                    if(!r.next()){JOptionPane.showMessageDialog(this,"Invalid email or password.");return;}
                    int id=r.getInt(1);String name=r.getString(2),detail=r.getString(3);
                    if(admin)new Admin(id,name,detail).setVisible(true);else new Student(id,name,detail).setVisible(true);
                    dispose();
                }
            }catch(Exception ex){error(this,ex);}
        }
    }

    static class Student extends JFrame {
        final int studentId; final String studentName;
        JComboBox<String> category=new JComboBox<>(new String[]{"Academic","Hostel","Food","Physical Harassment","Verbal Harassment","Other"});
        JTextArea desc=new JTextArea(6,35); JTextField evidence=new JTextField(30), trackId=new JTextField(8);
        JLabel result=new JLabel("Enter a complaint ID and select Find Status.");
        JTable table=new JTable();
        Student(int id,String name,String dept){
            studentId=id;studentName=name;setTitle("CollegeComplaint - Student Portal");setDefaultCloseOperation(EXIT_ON_CLOSE);
            setSize(900,650);setLocationRelativeTo(null);
            JLabel welcome=new JLabel("Student Dashboard — "+name+" ("+dept+")");welcome.setFont(new Font("SansSerif",Font.BOLD,22));
            JPanel root=new JPanel(new BorderLayout(10,10));root.setBorder(new EmptyBorder(18,20,18,20));root.add(welcome,BorderLayout.NORTH);
            JTabbedPane tabs=new JTabbedPane();tabs.addTab("File Complaint",form());tabs.addTab("Track Complaint",tracking());tabs.addTab("My Complaints",mine());root.add(tabs);add(root);
        }
        JPanel form(){
            JPanel p=new JPanel(new GridBagLayout());p.setBorder(new EmptyBorder(18,20,18,20));
            GridBagConstraints g=new GridBagConstraints();g.insets=new Insets(8,8,8,8);g.fill=GridBagConstraints.HORIZONTAL;g.anchor=GridBagConstraints.WEST;
            g.gridx=0;g.gridy=0;p.add(new JLabel("Category"),g);g.gridx=1;p.add(category,g);
            g.gridx=0;g.gridy++;p.add(new JLabel("Description"),g);g.gridx=1;desc.setLineWrap(true);desc.setWrapStyleWord(true);p.add(new JScrollPane(desc),g);
            g.gridx=0;g.gridy++;p.add(new JLabel("Evidence filename (optional)"),g);g.gridx=1;p.add(evidence,g);
            g.gridx=1;g.gridy++;JButton submit=btn("Submit Complaint");p.add(submit,g);submit.addActionListener(e->submit());return p;
        }
        JPanel tracking(){
            JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT,12,25));p.add(new JLabel("Complaint ID"));p.add(trackId);JButton find=btn("Find Status");p.add(find);p.add(result);
            find.addActionListener(e->track());return p;
        }
        JPanel mine(){
            JPanel p=new JPanel(new BorderLayout(8,8));JButton refresh=btn("Refresh");p.add(refresh,BorderLayout.NORTH);p.add(new JScrollPane(table));
            refresh.addActionListener(e->loadMine());loadMine();return p;
        }
        void submit(){
            if(desc.getText().trim().isEmpty()){JOptionPane.showMessageDialog(this,"Enter a description.");return;}
            String sql="INSERT INTO complaints(student_id,category,description,evidence,status,date_filed) VALUES(?,?,?,?, 'Pending', ?)";
            try(Connection c=connect();PreparedStatement s=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
                s.setInt(1,studentId);s.setString(2,(String)category.getSelectedItem());s.setString(3,desc.getText().trim());
                s.setString(4,evidence.getText().trim().isEmpty()?null:evidence.getText().trim());s.setDate(5,Date.valueOf(LocalDate.now()));s.executeUpdate();
                try(ResultSet k=s.getGeneratedKeys()){int id=k.next()?k.getInt(1):-1;JOptionPane.showMessageDialog(this,"Complaint submitted. Your complaint ID: "+id);trackId.setText(id>0?""+id:"");}
                desc.setText("");evidence.setText("");loadMine();
            }catch(Exception ex){error(this,ex);}
        }
        void track(){
            try{int id=Integer.parseInt(trackId.getText().trim());
                String q="SELECT complaint_id,category,status,date_filed,remarks FROM complaints WHERE complaint_id=? AND student_id=?";
                try(Connection c=connect();PreparedStatement s=c.prepareStatement(q)){s.setInt(1,id);s.setInt(2,studentId);
                    try(ResultSet r=s.executeQuery()){if(r.next())result.setText("ID "+r.getInt(1)+" | "+r.getString(2)+" | "+r.getString(3)+" | Filed: "+r.getDate(4)+" | Remarks: "+r.getString(5));
                    else result.setText("Complaint not found for your account.");}}
            }catch(NumberFormatException ex){JOptionPane.showMessageDialog(this,"Enter a numeric complaint ID.");}catch(Exception ex){error(this,ex);}
        }
        void loadMine(){
            try(Connection c=connect();PreparedStatement s=c.prepareStatement("SELECT complaint_id,category,status,date_filed,remarks FROM complaints WHERE student_id=? ORDER BY complaint_id DESC")){
                s.setInt(1,studentId);try(ResultSet r=s.executeQuery()){table.setModel(model(r));}
            }catch(Exception ex){error(this,ex);}
        }
    }

    static class Admin extends JFrame {
        JTable table=new JTable(); JTextField id=new JTextField(6),remarks=new JTextField(24);
        JComboBox<String> status=new JComboBox<>(new String[]{"Pending","In Progress","Resolved"});
        Admin(int adminId,String name,String role){
            setTitle("CollegeComplaint - Administrator Portal");setDefaultCloseOperation(EXIT_ON_CLOSE);setSize(1100,650);setLocationRelativeTo(null);
            JLabel title=new JLabel("Administrator Dashboard — "+name+" ("+role+")");title.setFont(new Font("SansSerif",Font.BOLD,22));
            JPanel root=new JPanel(new BorderLayout(10,10));root.setBorder(new EmptyBorder(18,20,18,20));root.add(title,BorderLayout.NORTH);
            JPanel center=new JPanel(new BorderLayout(8,8));JButton refresh=btn("Refresh Complaints");center.add(refresh,BorderLayout.NORTH);
            table.setAutoCreateRowSorter(true);center.add(new JScrollPane(table),BorderLayout.CENTER);refresh.addActionListener(e->load());
            JPanel bottom=new JPanel(new FlowLayout(FlowLayout.LEFT));bottom.add(new JLabel("Complaint ID"));bottom.add(id);bottom.add(new JLabel("Status"));bottom.add(status);bottom.add(new JLabel("Remarks"));bottom.add(remarks);
            JButton save=btn("Save Update");bottom.add(save);save.addActionListener(e->update());center.add(bottom,BorderLayout.SOUTH);root.add(center);add(root);load();
        }
        void load(){
            String q="SELECT c.complaint_id,c.student_id,s.name AS student_name,c.category,c.description,c.evidence,c.status,c.date_filed,c.remarks FROM complaints c LEFT JOIN students s ON c.student_id=s.student_id ORDER BY c.complaint_id DESC";
            try(Connection c=connect();PreparedStatement s=c.prepareStatement(q);ResultSet r=s.executeQuery()){table.setModel(model(r));}
            catch(Exception ex){error(this,ex);}
        }
        void update(){
            try{int cid=Integer.parseInt(id.getText().trim());String q="UPDATE complaints SET status=?,remarks=? WHERE complaint_id=?";
                try(Connection c=connect();PreparedStatement s=c.prepareStatement(q)){s.setString(1,(String)status.getSelectedItem());s.setString(2,remarks.getText().trim());s.setInt(3,cid);
                    int n=s.executeUpdate();JOptionPane.showMessageDialog(this,n==0?"Complaint ID not found.":"Complaint updated.");if(n>0)load();}
            }catch(NumberFormatException ex){JOptionPane.showMessageDialog(this,"Enter a valid numeric complaint ID.");}catch(Exception ex){error(this,ex);}
        }
    }
}
